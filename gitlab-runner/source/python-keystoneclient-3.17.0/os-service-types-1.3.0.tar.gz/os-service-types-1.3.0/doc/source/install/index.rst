============
Installation
============

At the command line::

    $ pip install os-service-types

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv os-service-types
    $ pip install os-service-types
